<?php

$ch = curl_init();

$subnet = $_GET['SubnetId'];
$cloud  = $_GET['Cloud'];
$region = $_GET['Region'] ;

curl_setopt($ch, CURLOPT_URL, "http://35.224.18.58:8080/getservers");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"SubnetId\":\"$subnet\",\"Cloud\": {\"Cloud\":\"$cloud\",\"Region\":\"$region\"}}");
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


$headers = array();
$headers[] = "Content-Type: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close ($ch);
print_r($result);
?>
