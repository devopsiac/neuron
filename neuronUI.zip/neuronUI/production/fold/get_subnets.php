<?php

function getme_subnets() {

$ch = curl_init();

$cloud  = "aws";
$region = "eu-west-3";

curl_setopt($ch, CURLOPT_URL, "http://35.224.18.58:8080/getsubnets");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"Cloud\":\"$cloud\",\"Region\":\"$region\"}");
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


$headers = array();
$headers[] = "Content-Type: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close ($ch);
$string_value = str_replace(array( '[', ']', '"' ), '', $result);
$value_ar = explode(',', $string_value);
return $value_ar;
}
?>
