<?php

function get_servers() {
$ch = curl_init();


$cloud  = "aws";
$region = "eu-west-3";

curl_setopt($ch, CURLOPT_URL, "http://localhost:8080/getallservers");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"Cloud\":\"$cloud\",\"Region\":\"$region\"}");
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


$headers = array();
$headers[] = "Content-Type: application/json";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close ($ch);

$array_json = json_decode($result, true);
#print_r($array_json);
return $array_json;

}
?>
